import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class SpinnerService {
  
  spinnerState: boolean = false
  spinnerText: string = 'Loading...'
  
  spinner = new Subject()
  spinnerMessage = new Subject()
  constructor() { }

  setSpinnerState(value : boolean) {
    this.spinnerState = value
    this.spinner.next(this.spinnerState)
  }

  setSpinnerMessage(value : string) {
    this.spinnerText = value
    this.spinnerMessage.next(this.spinnerText)
  }

}
