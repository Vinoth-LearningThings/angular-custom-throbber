import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComponentOneComponent } from './component-one/component-one.component'
import { ComponentTwoComponent } from './component-two/component-two.component'

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'component1',
        component: ComponentOneComponent
      },
      {
        path: 'component2',
        component: ComponentTwoComponent
      }
    ]
  }
]

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ]
})
export class AppRoutingModule { }