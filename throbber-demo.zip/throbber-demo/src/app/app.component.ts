import { Component, OnInit } from '@angular/core';
import { SpinnerService } from './spinner.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  displaySpinner: boolean = false
  spinnerMessage: string = 'Loading...'

  constructor(private spinnerService:SpinnerService, private router:Router) { }

  ngOnInit() {
    this.spinnerService.spinner.subscribe((value: boolean) => {
      this.displaySpinner = value
    })
    this.spinnerService.spinnerMessage.subscribe((message: string) => {
      this.spinnerMessage = message
    })
  }

  loadComponent(routeName) {
    this.spinnerService.setSpinnerState(true)
    if(routeName.indexOf('1') > -1) {
      this.spinnerService.setSpinnerMessage('Lorem ipsum dolor sit amet')
    } else {
      this.spinnerService.setSpinnerMessage('Consectetur adipiscing elit')
    }
    setTimeout(() => {
      this.spinnerService.setSpinnerState(false)
      this.router.navigateByUrl(routeName)
    }, 2000);
  }
}
